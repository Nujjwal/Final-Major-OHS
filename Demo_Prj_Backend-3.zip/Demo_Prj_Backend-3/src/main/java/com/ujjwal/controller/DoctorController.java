package com.ujjwal.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;

import com.ujjwal.model.Doctor;
import com.ujjwal.model.DoctorSpecialization;
import com.ujjwal.service.DocSpecService;
import com.ujjwal.service.DoctorService;

@CrossOrigin(origins = "http://localhost:3000")
@Controller
@RequestMapping("/api/v1/")
public class DoctorController {

	@Autowired
	private DocSpecService docSpecService;

	@Autowired
	private DoctorService doctorService;

	@PostMapping("/save")
	public ResponseEntity<Doctor> createDoctor(@RequestBody Doctor doctor) {
		return new ResponseEntity<Doctor>(doctorService.createDoctor(doctor), HttpStatus.CREATED);
	}

	@GetMapping("/")
	public ResponseEntity<List<Doctor>> getAllDoctor() {
		return new ResponseEntity<List<Doctor>>(doctorService.getAllDoctor(), HttpStatus.OK);
	}

	@GetMapping("/{d_Id}")
	public ResponseEntity<Doctor> getDoctorById(@PathVariable int d_Id) {
		return new ResponseEntity<Doctor>(doctorService.getDoctorById(d_Id), HttpStatus.OK);
	}

	@GetMapping("/delete/{d_Id}")
	public ResponseEntity<String> deleteDoctor(@PathVariable int d_Id) {
		doctorService.deleteDoctor(d_Id);
		return new ResponseEntity<String>("Delete Successfully", HttpStatus.OK);
	}

	@PostMapping("/update/{d_Id}")
	public ResponseEntity<Doctor> updateDoctor(@PathVariable int d_Id, @RequestBody Doctor doctor) {
		return new ResponseEntity<Doctor>(doctorService.updateDoctor(d_Id, doctor), HttpStatus.OK);
	}

	@PostMapping("/addSpec")
	public ResponseEntity<DoctorSpecialization> createSpecialization(
			@RequestBody DoctorSpecialization doctorSpecialization) {
		return new ResponseEntity<DoctorSpecialization>(docSpecService.createSpecialization(doctorSpecialization),
				HttpStatus.OK);
	}

	@GetMapping("/viewSpec")
	public ResponseEntity<List<DoctorSpecialization>> getAllSpecializations() {
		return new ResponseEntity<List<DoctorSpecialization>>(docSpecService.getAllSpecializations(), HttpStatus.OK);
	}

	@GetMapping("/viewSpecById/{sp_Id}")
	public ResponseEntity<DoctorSpecialization> getSpecializationById(@PathVariable int sp_Id) {
		return new ResponseEntity<DoctorSpecialization>(docSpecService.getSpecializationById(sp_Id), HttpStatus.OK);
	}

	@GetMapping("/deleteSpec/{sp_Id}")
	public ResponseEntity<String> deleteSpecialization(@PathVariable int sp_Id) {
		docSpecService.deleteSpecialization(sp_Id);
		return new ResponseEntity<String>("Specialization Deleted Successfully", HttpStatus.OK);
	}
}
