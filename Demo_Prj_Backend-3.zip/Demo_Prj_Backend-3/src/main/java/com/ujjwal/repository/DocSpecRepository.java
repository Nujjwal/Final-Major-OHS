package com.ujjwal.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.ujjwal.model.DoctorSpecialization;

public interface DocSpecRepository extends JpaRepository<DoctorSpecialization, Integer> {

}
