package com.ujjwal.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;

import com.ujjwal.model.DoctorSpecialization;

public interface DocSpecService {

	@Autowired
	public DoctorSpecialization createSpecialization(DoctorSpecialization doctorSpecialization);

	public List<DoctorSpecialization> getAllSpecializations();

	public DoctorSpecialization getSpecializationById(int sp_Id);

	public void deleteSpecialization(int sp_Id);

}
