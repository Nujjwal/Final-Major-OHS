package com.ujjwal.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.ujjwal.model.DoctorSpecialization;
import com.ujjwal.repository.DocSpecRepository;

@Service
public class DocSpecServiceImpl implements DocSpecService {

	@Autowired
	private DocSpecRepository docSpecRepo;

	@Override
	public DoctorSpecialization createSpecialization(DoctorSpecialization doctorSpecialization) {
		return docSpecRepo.save(doctorSpecialization);
	}

	@Override
	public List<DoctorSpecialization> getAllSpecializations() {
		return docSpecRepo.findAll();
	}

	@Override
	public DoctorSpecialization getSpecializationById(int sp_Id) {
		return docSpecRepo.findById(sp_Id).get();
	}

	@Override
	public void deleteSpecialization(int sp_Id) {
		DoctorSpecialization doctorSpecialization = docSpecRepo.findById(sp_Id).get();

		if (doctorSpecialization != null) {
			docSpecRepo.delete(doctorSpecialization);
		}
	}

}
