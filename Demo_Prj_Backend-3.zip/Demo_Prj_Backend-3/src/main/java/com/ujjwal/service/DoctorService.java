package com.ujjwal.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;

import com.ujjwal.model.Doctor;

public interface DoctorService {

	@Autowired
	public Doctor createDoctor(Doctor doctor);

	public List<Doctor> getAllDoctor();

	public Doctor getDoctorById(int d_Id);

	public void deleteDoctor(int d_Id);

	public Doctor updateDoctor(int d_Id, Doctor doctor);

}
