package com.ujjwal.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.ujjwal.model.Doctor;
import com.ujjwal.repository.DoctorRepository;

@Service
public class DoctorServiceImpl implements DoctorService {

	@Autowired
	private DoctorRepository doctorRepo;

	@Override
	public Doctor createDoctor(Doctor doctor) {
		return doctorRepo.save(doctor);
	}

	@Override
	public List<Doctor> getAllDoctor() {
		return doctorRepo.findAll();
	}

	@Override
	public Doctor getDoctorById(int d_Id) {
		return doctorRepo.findById(d_Id).get();
	}

	@Override
	public void deleteDoctor(int d_Id) {
		Doctor doctor = doctorRepo.findById(d_Id).get();

		if (doctor != null) {
			doctorRepo.delete(doctor);
		}
	}

	@Override
	public Doctor updateDoctor(int d_Id, Doctor doctor) {
		Doctor oldDoctor = doctorRepo.findById(d_Id).get();
		if (oldDoctor != null) {
			doctor.setD_Id(d_Id);
			return doctorRepo.save(doctor);
		}
		return null;
	}

}
