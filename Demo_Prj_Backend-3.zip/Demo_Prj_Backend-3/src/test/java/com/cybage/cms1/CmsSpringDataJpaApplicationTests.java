package com.cybage.cms1;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CmsSpringDataJpaApplicationTests {

	@Test
	void contextLoads() {
	}

}
