import { Routes,Route } from 'react-router-dom';
import './App.css';
import AddDoctor from './components/AddDoctor';
import EditDoctor from './components/EditDoctor';
import ViewDoctor from './components/ViewDoctor';
import ViewSpecialization from './components/ViewSpecialization';
import AddSpecialization from './components/AddSpecialization';
import Navbar from './components/Navbar';

function App() {
  return (
    <div className="App">
      <Navbar></Navbar>
      <Routes>
        <Route path="/" element={<ViewDoctor />}></Route>
        <Route path="/ViewSpecialization" element={<ViewSpecialization />}></Route>

        <Route path="/AddDoctor" element={<AddDoctor />}></Route>
        <Route path="/AddSpecialization" element={<AddSpecialization />}></Route>

        <Route path="/editDoctor/:id" element={<EditDoctor />}></Route>
      </Routes>
    </div>
  );
}

export default App;
