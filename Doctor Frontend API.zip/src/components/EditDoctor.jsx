import React, { useEffect, useState } from 'react';
import { useNavigate, useParams } from 'react-router-dom';
import doctorService from '../service/doctor.service';

const EditDoctor = () => {
    const [doctor, setDoctor] = useState({
        d_Name: "",
        d_Email: "",
        d_Password: "",
        // d_Specialization:"",
        d_Mobile: "",
        d_Address: ""
    });

    const [msg, setMsg] = useState("");

    // const d_Id = useParams();
    // console.log(d_Id.id);

    const data = useParams();
    const navigate = useNavigate();

    useEffect(() => {
        doctorService.getDoctorById(data.id).then((res) => {
            setDoctor(res.data)
        }).catch((error) => {
            console.log(error);
        });
    }, [data.id]);

    const handleChange = (e) => {
        const value = e.target.value;
        setDoctor({ ...doctor, [e.target.name]: value });
    };

    const updateDoctor = (e) => {
        e.preventDefault();
        doctorService
            .updateDoctor(doctor.d_Id, doctor)
            .then(res => {
                navigate("/");
            })
            .catch((error) => {
                console.log(error);
            });
    };

    return (
        <div>
            <div className="container">
                <div className="row">
                    <div className="col-md-6 offset-md-3">
                        <div className="card">
                            <div className="card-header text-center fs-3">Edit Doctor Details
                                {
                                    msg && <p className="text-success">{msg}</p>
                                }
                            </div>
                            <div className="card-body">
                                <form onSubmit={(e) => updateDoctor(e)}>
                                    <div className="mb-3">
                                        <label>Enter Full Name</label>
                                        <input className="form-control" type="text"
                                            name="d_Name" value={doctor.d_Name} onChange={(e) => handleChange(e)} required />
                                    </div>
                                    <div className="mb-3">
                                        <label>Enter Email</label>
                                        <input className="form-control" type="email"
                                            name="d_Email" value={doctor.d_Email} onChange={(e) => handleChange(e)} required />
                                    </div>
                                    <div className="mb-3">
                                        <label>Enter Mobile</label>
                                        <input className="form-control" type="number"
                                            name="d_Mobile" value={doctor.d_Mobile} onChange={(e) => handleChange(e)} required />
                                    </div>
                                    <div className="mb-3">
                                        <label>Enter Address</label>
                                        <input className="form-control" type="text"
                                            name="d_Address" value={doctor.d_Address} onChange={(e) => handleChange(e)} required />
                                    </div>
                                    <div className="text-center">
                                        <button className="btn btn-success m-2">Submit</button>
                                        <button onClick={() => navigate("/", { replace: true })} className="btn btn-primary">Back to Home</button>

                                    </div>
                                </form>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    )
}

export default EditDoctor;