import React, { useEffect, useState } from "react";
import { useNavigate } from 'react-router-dom';
import doctorService from "../service/doctor.service";

const ViewSpecialization = () => {

    const [specializationList, setSpecializationList] = useState([]);
    const [msg, setMsg] = useState("");
    const navigate = useNavigate();


    useEffect(() => {
        init();
    }, []);

    const init = () => {
        doctorService.getAllSpecializations().then((res) => {
        //    console.log(res.data);
            setSpecializationList(res.data);
        })
        .catch((error) => {
            console.log(error);
        });
    };

    const deleteSpecialization = (sp_Id) => {
        doctorService.deleteSpecialization(sp_Id).then((res) => {
            setMsg("Specialization Deleted Successfully");
            init();
        }).catch((error) => {
            console.log(error);
        });
    }

    return (
        <div className="container">
            <h1 className="text-center mt-3">HealthCare System</h1>
            {msg && <p className="text-center text-success">{msg}</p>}
            <table className="table mt-5">
                <thead className="bg-light">
                    <tr>
                        <th scope="col">Id</th>
                        <th scope="col">Doctor_Specialization</th>
                        <th scope="col" >Action</th>
                    </tr>
                </thead>
                <tbody>
                    {specializationList.map((e, num) => (
                        <tr>
                            <th scope="row" key={e.sp_Id}>{num + 1}</th>
                            <td>{e.d_Specialization}</td>
                            <td>
                                <a onClick={() => deleteSpecialization(e.sp_Id)} className="btn btn-sm btn-danger" href="#">Delete</a>
                            </td>
                        </tr>
                    ))}
                </tbody>
            </table>
            <div className="text-center">
            <button onClick={() => navigate("/AddSpecialization", { replace: true })} className="btn btn-primary">Add Specialization</button>
            </div>
        </div>
    );
}

export default ViewSpecialization;


