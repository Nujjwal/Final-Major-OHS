import axios from "axios";


const BASE_API_URL = "http://localhost:8080/api/v1";


class DoctorService{

    saveDoctor(doctor){
        return axios.post(BASE_API_URL + "/save/", doctor);
    }

    getAllDoctor(){
        return axios.get(BASE_API_URL + "/" );
    }

    getDoctorById(d_Id){
        return axios.get(BASE_API_URL + "/" + d_Id);
    }

    deleteDoctor(d_Id){
        return axios.get(BASE_API_URL + "/delete/" + d_Id);
    }

    updateDoctor(d_Id,doctor){
        axios.post(BASE_API_URL + "/update/" + d_Id, doctor);
    }

    addSpecialization(doctorSpecialization){
        return axios.post(BASE_API_URL + "/addSpec/", doctorSpecialization);
    }

    getAllSpecializations(){
        return axios.get(BASE_API_URL + "/viewSpec" );
    }

    getSpecializationById(sp_Id){
        return axios.get(BASE_API_URL + "/viewSpecById/" + sp_Id);
    }

    deleteSpecialization(sp_Id){
        return axios.get(BASE_API_URL + "/deleteSpec/" +  sp_Id);
    }

}

export default new DoctorService();