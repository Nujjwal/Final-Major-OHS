package com.cybage.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.cybage.model.Appointment;
import com.cybage.service.AppointmentService;

@CrossOrigin
@RestController
@RequestMapping("/appointment")
public class AppointmentController {

	@Autowired
	private AppointmentService appointmentService;

	@PostMapping("/add")
	public ResponseEntity<Appointment> createAppointment(@RequestBody Appointment appointment) {
		return new ResponseEntity<Appointment>(appointmentService.createAppointment(appointment), HttpStatus.CREATED);
	}

	@GetMapping("/")
	public ResponseEntity<List<Appointment>> getAllAppointment() {
		return new ResponseEntity<List<Appointment>>(appointmentService.getAllAppointment(), HttpStatus.OK);
	}

	@GetMapping("/{appointment_Id}")
	public ResponseEntity<Appointment> getAppointmentById(@PathVariable int appointment_Id) {
		return new ResponseEntity<Appointment>(appointmentService.getAppointmentById(appointment_Id), HttpStatus.OK);
	}

	@DeleteMapping("/delete/{appointment_Id}")
	public ResponseEntity<String> deleteAppointment(@PathVariable int appointment_Id) {
		appointmentService.deleteAppointment(appointment_Id);
		return new ResponseEntity<String>("Appointment Deleted Successfully", HttpStatus.OK);
	}
}
