package com.cybage.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.cybage.model.Doctor;
import com.cybage.model.DoctorSpecialization;
import com.cybage.service.DocSpecService;
import com.cybage.service.DoctorService;

@CrossOrigin
@RestController
@RequestMapping("/doctor")
public class DoctorController {

	@Autowired
	private DocSpecService docSpecService;
	
	@Autowired
	private DoctorService doctorService;

	@PostMapping("/")
	public ResponseEntity<Doctor> createDoctor(@RequestBody Doctor doctor) {
		return new ResponseEntity<Doctor>(doctorService.createDoctor(doctor), HttpStatus.CREATED);
	}

	@GetMapping("/")
	public ResponseEntity<List<Doctor>> getAllDoctor() {
		return new ResponseEntity<List<Doctor>>(doctorService.getAllDoctor(), HttpStatus.OK);
	}

	@GetMapping("/{doctor_Id}")
	public ResponseEntity<Doctor> getDoctorById(@PathVariable int doctor_Id) {
		return new ResponseEntity<Doctor>(doctorService.getDoctorById(doctor_Id), HttpStatus.OK);
	}

	@DeleteMapping("/delete/{doctor_Id}")
	public ResponseEntity<String> deleteDoctor(@PathVariable int doctor_Id) {
		doctorService.deleteDoctor(doctor_Id);
		return new ResponseEntity<String>("Doctor Deleted Successfully", HttpStatus.OK);
	}
	
	@PutMapping("/update/{doctor_Id}")
	public ResponseEntity<Doctor> updateDoctor(@PathVariable int doctor_Id, @RequestBody Doctor doctor) {
		return new ResponseEntity<Doctor>(doctorService.updateDoctor(doctor_Id, doctor), HttpStatus.OK);
	}
	

	@PostMapping("/addSpec")
	public ResponseEntity<DoctorSpecialization> createSpecialization(
			@RequestBody DoctorSpecialization doctorSpecialization) {
		return new ResponseEntity<DoctorSpecialization>(docSpecService.createSpecialization(doctorSpecialization),
				HttpStatus.OK);
	}

	@GetMapping("/viewSpec")
	public ResponseEntity<List<DoctorSpecialization>> getAllSpecializations() {
		return new ResponseEntity<List<DoctorSpecialization>>(docSpecService.getAllSpecializations(), HttpStatus.OK);
	}

	@GetMapping("/viewSpecById/{specialization_Id}")
	public ResponseEntity<DoctorSpecialization> getSpecializationById(@PathVariable int specialization_Id) {
		return new ResponseEntity<DoctorSpecialization>(docSpecService.getSpecializationById(specialization_Id), HttpStatus.OK);
	}

	@DeleteMapping("/deleteSpec/{specialization_Id}")
	public ResponseEntity<String> deleteSpecialization(@PathVariable int specialization_Id) {
		docSpecService.deleteSpecialization(specialization_Id);
		return new ResponseEntity<String>("Specialization Deleted Successfully", HttpStatus.OK);
	}

}
