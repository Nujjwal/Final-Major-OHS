package com.cybage.model;

import java.sql.Date;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.sun.istack.NotNull;

import lombok.Data;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@NoArgsConstructor
@Entity
@Table(name = "Appointment")
public class Appointment {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "appointment_id")
	private int appointment_Id;
	
	@Column(name = "appointment_status")
	private String appointment_Status;
	
	@Column(name="appointment_datetime")
	private String appointment_DateTime;
		
	@Column(name="bookedon")
	private String BookedOn;

	@ManyToOne
	@JoinColumn(name = "doctor_Id")
	private Doctor doc;

	@ManyToOne
	@JoinColumn(name = "patient_Id")
	private Patient pat;

}
