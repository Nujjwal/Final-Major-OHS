package com.cybage.model;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.Table;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.sun.istack.NotNull;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@NoArgsConstructor
@Entity
@Table(name = "Doctor")
public class Doctor {


	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "doctor_id")
	private int doctor_Id;

	@NotNull
	@Column(name = "doctor_name")
	private String doctor_Name;

	@NotNull
	@Column(name = "doctor_email")
	private String doctor_Email;

	@NotNull
	@Column(name = "doctor_password")
	private String doctor_Password;

	@NotNull
	@Column(name = "doctor_specialization")
	private String doctor_Specialization;

	@NotNull
	@Column(name = "doctor_address")
	private String doctor_Address;

	@NotNull
	@Column(name = "doctor_mobile")
	private String doctor_Mobile;

	@JsonIgnore
	@OneToMany(mappedBy = "doc")
	private List<Appointment> appointment = new ArrayList<>();
}
