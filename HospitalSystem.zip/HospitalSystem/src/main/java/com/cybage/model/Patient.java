package com.cybage.model;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.Table;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.sun.istack.NotNull;

import lombok.Data;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@NoArgsConstructor
@Entity
@Table(name = "Patient")
public class Patient {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "patient_id")
	private int patient_Id;

	@Column(name = "patient_name")
	private String patient_Name;

	@Column(name = "patient_address")
	private String patient_Address;
	
	@Column(name = "patient_email")
	private String patient_Email;

	@Column(name = "patient_password")
	private String patient_Password;
	
	@Column(name = "patient_age")
	private String patient_Age;
	
	@Column(name = "patient_sex")
	private String patient_Sex;
	
	@JsonIgnore
	@OneToMany(mappedBy = "pat")
	private List<Appointment> appointment = new ArrayList<>();
}
