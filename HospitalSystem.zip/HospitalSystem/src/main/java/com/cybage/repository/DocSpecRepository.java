package com.cybage.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.cybage.model.DoctorSpecialization;

public interface DocSpecRepository extends JpaRepository<DoctorSpecialization, Integer> {

}
