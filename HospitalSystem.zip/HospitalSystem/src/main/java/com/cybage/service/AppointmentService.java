package com.cybage.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import com.cybage.model.Appointment;

public interface AppointmentService {

	@Autowired
	public Appointment createAppointment(Appointment appointment);

	public List<Appointment> getAllAppointment();

	public Appointment getAppointmentById(int appointment_Id);

	public void deleteAppointment(int appointment_Id);
	
	
	

}
