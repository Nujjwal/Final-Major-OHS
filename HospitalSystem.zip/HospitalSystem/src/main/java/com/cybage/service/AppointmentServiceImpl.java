package com.cybage.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.stereotype.Service;
import org.springframework.web.servlet.config.annotation.CorsRegistry;
import org.springframework.web.servlet.config.annotation.WebMvcConfigurer;

import com.cybage.model.Appointment;
import com.cybage.repository.AppointmentRepository;

@Service
public class AppointmentServiceImpl implements AppointmentService {

	@Autowired
	private AppointmentRepository appointmentRepo;

	@Override
	public Appointment createAppointment(Appointment appointment) {
		return appointmentRepo.save(appointment);
	}

	@Override
	public List<Appointment> getAllAppointment() {
		return appointmentRepo.findAll();
	}

	@Override
	public Appointment getAppointmentById(int appointment_Id) {
		return appointmentRepo.findById(appointment_Id).get();
	}

	@Override
	public void deleteAppointment(int appointment_Id) {
		Appointment appointment = appointmentRepo.findById(appointment_Id).get();
		if (appointment != null) {
			appointmentRepo.delete(appointment);
		}
	}

	

}
