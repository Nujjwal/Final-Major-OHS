package com.cybage.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;

import com.cybage.model.DoctorSpecialization;

public interface DocSpecService {

	@Autowired
	public DoctorSpecialization createSpecialization(DoctorSpecialization doctorSpecialization);

	public List<DoctorSpecialization> getAllSpecializations();

	public DoctorSpecialization getSpecializationById(int specialization_Id);

	public void deleteSpecialization(int specialization_Id);

}
