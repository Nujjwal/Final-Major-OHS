package com.cybage.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cybage.model.DoctorSpecialization;
import com.cybage.repository.DocSpecRepository;

@Service
public class DocSpecServiceImpl implements DocSpecService {

	@Autowired
	private DocSpecRepository docSpecRepo;

	@Override
	public DoctorSpecialization createSpecialization(DoctorSpecialization doctorSpecialization) {
		return docSpecRepo.save(doctorSpecialization);
	}

	@Override
	public List<DoctorSpecialization> getAllSpecializations() {
		return docSpecRepo.findAll();
	}

	@Override
	public DoctorSpecialization getSpecializationById(int specialization_Id) {
		return docSpecRepo.findById(specialization_Id).get();
	}

	@Override
	public void deleteSpecialization(int specialization_Id) {
		DoctorSpecialization doctorSpecialization = docSpecRepo.findById(specialization_Id).get();

		if (doctorSpecialization != null) {
			docSpecRepo.delete(doctorSpecialization);
		}
	}

}
