package com.cybage.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;

import com.cybage.model.Doctor;

public interface DoctorService {

	@Autowired
	public Doctor createDoctor(Doctor doctor);

	public List<Doctor> getAllDoctor();

	public Doctor getDoctorById(int doctor_Id);

	public void deleteDoctor(int doctor_Id);
	
	public Doctor updateDoctor(int doctor_Id, Doctor doctor);
}
