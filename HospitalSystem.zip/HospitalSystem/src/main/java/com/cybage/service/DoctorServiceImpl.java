package com.cybage.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cybage.model.Doctor;
import com.cybage.repository.DoctorRepository;

@Service
public class DoctorServiceImpl implements DoctorService {

	@Autowired
	private DoctorRepository doctorRepo;

	@Override
	public Doctor createDoctor(Doctor doctor) {
		return doctorRepo.save(doctor);
	}

	@Override
	public List<Doctor> getAllDoctor() {
		return doctorRepo.findAll();
	}

	@Override
	public Doctor getDoctorById(int doctor_Id) {
		return doctorRepo.findById(doctor_Id).get();
	}

	@Override
	public void deleteDoctor(int doctor_Id) {

		Doctor doctor = doctorRepo.findById(doctor_Id).get();
		if (doctor != null) {
			doctorRepo.delete(doctor);
		}
	}
	
	@Override
	public Doctor updateDoctor(int doctor_Id, Doctor doctor) {
		Doctor oldDoctor = doctorRepo.findById(doctor_Id).get();
		if (oldDoctor != null) {
			doctor.setDoctor_Id(doctor_Id);
			return doctorRepo.save(doctor);
		}
		return null;
	}

}
