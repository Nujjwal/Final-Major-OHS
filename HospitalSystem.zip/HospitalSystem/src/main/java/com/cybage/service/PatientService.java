package com.cybage.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;

import com.cybage.model.Patient;

public interface PatientService {

	@Autowired
	public Patient createPatient(Patient patient);

	public List<Patient> getAllPatient();

	public Patient getPatientById(int patient_Id);

	public void deletePatient(int patient_Id);

}
