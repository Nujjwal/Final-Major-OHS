package com.cybage.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cybage.model.Patient;
import com.cybage.repository.PatientRepository;

@Service
public class PatientServiceImpl implements PatientService {

	@Autowired
	private PatientRepository patientRepo;

	@Override
	public Patient createPatient(Patient patient) {
		return patientRepo.save(patient);
	}

	@Override
	public List<Patient> getAllPatient() {
		return patientRepo.findAll();
	}

	@Override
	public Patient getPatientById(int patient_Id) {
		return patientRepo.findById(patient_Id).get();
	}

	@Override
	public void deletePatient(int patient_Id) {
		Patient patient = patientRepo.findById(patient_Id).get();

		if (patient != null) {
			patientRepo.delete(patient);
		}
	}

}
