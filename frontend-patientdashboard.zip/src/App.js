import "./App.css";
import Homepage from "./Patient/patienthomepage";
import DoctorsList from "./Components/DoctorsList";
import PatientAppointment from "./Components/PatientAppointment";


import {
  BrowserRouter as Router,
  Route,
  Routes,
  Link,
  useParams,
  useRouteMatch,
} from "react-router-dom";

import Footer from "./Patient/Footer";
import HomeImg from "./Components/homeimg";

function App() {
  return (
    <>
      <Homepage />      
      <Routes>
        <Route path="/doctors" element={<DoctorsList />} />
        <Route path="/patientAppointment" element={<PatientAppointment />}/>
        <Route path="/" element={<HomeImg />} />
        {/* <Route path="/doctors" element={<AppoitmentList />} /> */}
        {/* <Route path="/doctors" element={<DoctorsLIst />} /> */}
      </Routes>
      <Footer />
    </>
  );
}

export default App;
