import axios from "axios";
import { Modal, Box, Typography, TextField, Button } from "@mui/material";
import { makeStyles } from "@material-ui/core/styles";
import { useState } from "react";

const style = {
  position: "absolute",
  top: "50%",
  left: "50%",
  transform: "translate(-50%, -50%)",
  width: 500,
  bgcolor: "background.paper",
  border: "2px solid #000",
  boxShadow: 24,
  p: 4,
};

const useStyles = makeStyles((theme) => ({
  container: {
    display: "flex",
    flexWrap: "wrap",
  },
  textField: {
    marginLeft: theme.spacing(1),
    marginRight: theme.spacing(1),
    width: 200,
  },
}));

const BookAppointment = ({ handleClose, doctor }) => {
  
  const classes = useStyles();
  const [appointment, setAppointment] = useState("");

  const bookAppointment = () => {
    let month = new Date().getMonth() + 1

    const appointmentObj = {
      pat:{ 
        patient_Id: parseInt(localStorage.getItem("patient_id"))
      },
      doc: {
        doctor_Id: doctor.doctor_Id
      },
      a_DateTime: appointment,
      bookedOn: new Date().getDate() + "-" + month + "-" + new Date().getFullYear(),
      a_Status: 1
    };

    axios
      .post("http://localhost:8080/appointment/add/", appointmentObj)
      .then((resp) => { 
        if (resp.status === 201) {
          handleClose(true);
        }
      });
    // move this line to axios then
    // till here
  };

  return (
    <>
      <Modal
        open={true}
        onClose={() => handleClose(false)}
        aria-labelledby="modal-modal-title"
        aria-describedby="modal-modal-description"
      >
        <Box sx={style}>
          <Typography
            id="modal-modal-title"
            variant="h6"
            component="h2"
            sx={{ mb: 2 }}
          >
            Book Appointment for <b>{doctor.doctor_Name}</b>
          </Typography>

          <Typography
            id="modal-modal-title"
            variant="h6"
            component="h6"
            sx={{ mb: 4, fontSize: 15 }}
          >
            Specialization <b>{doctor.doctor_Specialization}</b>
          </Typography>

          <form className={classes.container} noValidate>
            <TextField
              id="datetime-local"
              label="Appointment Date & Time"
              type="datetime-local"
              defaultValue="2022-06-26T10:30"
              className={classes.textField}
              InputLabelProps={{
                shrink: true,
              }}
              onChange={(e) => {
                setAppointment(e.target.value);
              }}
            />
          </form>
          <Button sx={{ float: "right" }} onClick={() => bookAppointment()}>
            Book Appointment
          </Button>
        </Box>
      </Modal>
    </>
  );
};
export default BookAppointment;
