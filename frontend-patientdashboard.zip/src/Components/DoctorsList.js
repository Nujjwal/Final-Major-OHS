import React, { useState, useEffect } from "react";
import axios from "axios";
import SPECIALIZATION_API_BASE_URL from "../Constants/constants";

import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableRow,
  TableContainer,
  Paper,
  Select,
  Input,
  MenuItem,
  InputLabel,
  FormControl,
  Button,
  Typography,
  Snackbar,
  Alert,
} from "@mui/material";
import BookApointment from "./BookApointment";

export default function DoctorsList() {
  const [APIData, setAPIData] = useState([]);
  const [filteredResults, setFilteredResults] = useState([]);
  const [specializationFilters, setSpecializationFilters] = useState([]);
  const [specializationFilter, setSpecializationFilter] = useState("");
  const [specializationInput, setspecializationInput] = useState("");
  const [bookApointment, setBookApointment] = useState({
    show: false,
    doctorData: {},
    showAlert: false,
  });

  useEffect(() => {
    axios.get(SPECIALIZATION_API_BASE_URL).then((response) => {
      let specializationFilter = [];
      for (let i = 0; i < response.data.length; i++) {
        if (
          !specializationFilter.includes(response.data[i].doctor_Specialization)
        ) {
          specializationFilter.push(response.data[i].doctor_Specialization);
        }
      }

      setSpecializationFilters(specializationFilter);

      setAPIData(response.data);
    });
  }, []);

  useEffect(() => {
    if (specializationFilter !== "") {
      const filteredData = APIData.filter((data) => {
        if (data.doctor_Specialization === specializationFilter) {
          return data;
        }
      });
      setFilteredResults(filteredData);
    }
  }, [specializationFilter]);

  const searchItems = (searchValue) => {
    setspecializationInput(searchValue);
    if (searchValue !== "") {
      const filteredData = APIData.filter((specialization) => {
        return Object.values(specialization)
          .join("")
          .toLowerCase()
          .includes(searchValue.toLowerCase());
      });
      console.log(filteredData);
      setFilteredResults(filteredData);
    } else {
      setFilteredResults(APIData);
    }
  };

  return (
    <div className="container">
      {bookApointment.show && (
        <BookApointment
          doctor={bookApointment.doctorData}
          handleClose={(success) => {
            if (success)
              setBookApointment({
                ...bookApointment,
                show: false,
                showAlert: true,
              });
            else
              setBookApointment({
                show: false,
                doctorData: {},
                showAlert: false,
              });
          }}
        />
      )}

      <Snackbar
        open={bookApointment.showAlert}
        autoHideDuration={3000}
        onClose={() => {
          setBookApointment({
            ...bookApointment,
            showAlert: false,
          });
        }}
      >
        <Alert
          onClose={() => {
            setBookApointment({
              ...bookApointment,
            });
          }}
          severity="success"
        >
          Appointment for {bookApointment.doctorData.doctor_Name} booked
          successfully
        </Alert>
      </Snackbar>

      <div className="row">
        <Typography variant="h4" component="h5" style={{ marginTop: "3vh", color:"black" }}>
          Doctors
        </Typography>
        <div className="col-md-6" style={{ marginTop: "3vh" }}>
          <FormControl>
            <InputLabel id="search-label" style={{color:"black"}}>Search All</InputLabel>
            <Input
              icon="search"
              style={{ width: "25vw", height: "5vh" }}
              placeholder="Search All..."
              onChange={(e) => searchItems(e.target.value)}
            />
          </FormControl>
        </div>
        <div className="col-md-6">
          <FormControl variant="standard" style={{ marginTop: "3vh" }}>
            <InputLabel id="doctor-filter-label" style={{color:"black"}}>
              Search Specialization
            </InputLabel>
            <Select
              style={{ width: "25vw", height: "5vh" }}
              name="doctor-filter"
              onChange={(e) => {
                console.log("LOL");
                setSpecializationFilter(e.target.value);
              }}
              value={specializationFilter}
            >
              <MenuItem value="">All</MenuItem>
              {specializationFilters.map((specialization) => {
                return (
                  <MenuItem value={specialization}>{specialization}</MenuItem>
                );
              })}
            </Select>
          </FormControl>
        </div>
      </div>
      <br />
      <br />
      <TableContainer component={Paper}>
        <Table>
          <TableHead>
            <TableRow>
              <TableCell sx={{fontWeight:'Bold'}}> Sr No.</TableCell>
              <TableCell sx={{fontWeight:'Bold'}}> Doctor Address</TableCell>
              <TableCell sx={{fontWeight:'Bold'}}> Doctor Email</TableCell>
              <TableCell sx={{fontWeight:'Bold'}}> Doctor Mobile</TableCell>
              <TableCell sx={{fontWeight:'Bold'}}> Doctor Name</TableCell>
              <TableCell sx={{fontWeight:'Bold'}} sortDirection="asc"> Doctor Specialization</TableCell>
              <TableCell sx={{fontWeight:'Bold'}}sortDirection="asc">Book</TableCell>
            </TableRow>
          </TableHead>
          <TableBody>
            {specializationInput.length > 1 || specializationFilter !== ""
              ? filteredResults.map((specialization, index) => {
                  return (
                    <TableRow key={index + 1}>
                      <TableCell>{specialization.doctor_Id}</TableCell>
                      <TableCell> {specialization.doctor_Address}</TableCell>
                      <TableCell> {specialization.doctor_Email}</TableCell>
                      <TableCell> {specialization.doctor_Mobile}</TableCell>
                      <TableCell> {specialization.doctor_Name}</TableCell>
                      <TableCell>{specialization.doctor_Specialization}</TableCell>
                      <TableCell>
                        <Button
                          variant="outlined"
                          onClick={() => {
                            setBookApointment({
                              show: true,
                              doctorData: specialization,
                              showAlert: false,
                            });
                          }}
                        >
                          Book Now
                        </Button>
                      </TableCell>
                    </TableRow>
                  );
                })
              : APIData.length > 0 && APIData.map((specialization, index) => (
                  <TableRow key={specialization.doctor_Id}>
                    <TableCell>{index + 1}</TableCell>
                    <TableCell> {specialization.doctor_Address}</TableCell>
                    <TableCell> {specialization.doctor_Email}</TableCell>
                    <TableCell> {specialization.doctor_Mobile}</TableCell>
                    <TableCell> {specialization.doctor_Name}</TableCell>
                    <TableCell> {specialization.doctor_Specialization}</TableCell>
                    <TableCell>
                      <Button
                        variant="outlined"
                        onClick={() => {
                          setBookApointment({
                            show: true,
                            doctorData: specialization,
                            showAlert: false,
                          });
                        }}
                      >
                        Book Now
                      </Button>
                    </TableCell>
                  </TableRow>
                ))}
          </TableBody>
        </Table>
      </TableContainer>
    </div>
  );
}
