import React, { useEffect, useState } from "react";
import axios from "axios";
import { 
    TableContainer,
    Table,
    TableHead,
    TableRow,
    TableCell,
    Paper,
    TableBody,
    Typography

} from "@mui/material";

const PATIENTS_API_BASE_URL = "http://localhost:8080/appointment/";

export default function PatientAppointment() {
    const[displayAppointment, setDisplayAppointment] = useState([""]);

    useEffect(() => {
        axios.get(PATIENTS_API_BASE_URL)
           .then((response) => {
            console.log(response.data)
                setDisplayAppointment(response.data);
            })
    }, [])
    
    return (
            <TableContainer component={Paper}>
                <Table>
                    <TableHead>
                        <TableRow>
                            {/* <TableCell>Sr No.</TableCell> */}
                            <TableCell>Appointment ID </TableCell>
                            <TableCell>Appointment Booked On</TableCell>
                            <TableCell>Appointment Date & Time</TableCell>
                            <TableCell>Appointment Status</TableCell>
                            <TableCell>Doctor Name</TableCell>
                            <TableCell>Patient Name</TableCell>
                        </TableRow>
                    </TableHead>
                    <TableBody>
                        {displayAppointment.length > 0 && displayAppointment.map((patientAppointment) => { 
                            console.log(patientAppointment)
                            return (
                            <TableRow key={patientAppointment.a_Id}>
                                <TableCell>{patientAppointment.a_Id}</TableCell>
                                <TableCell>{patientAppointment.bookedOn}</TableCell> 
                                <TableCell>{patientAppointment.a_DateTime}</TableCell>
                                <TableCell>{patientAppointment.a_Status}</TableCell> 
                                <TableCell>{patientAppointment.doctor_Name}</TableCell> 
                                <TableCell>{patientAppointment.patient_Name}</TableCell> 
                            </TableRow>
                        )}
                            
                    )}
                    </TableBody>
                </Table>
            </TableContainer>
                       
    )
}