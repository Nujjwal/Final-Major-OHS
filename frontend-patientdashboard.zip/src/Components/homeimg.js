import React from "react";

export default function HomeImg() {
    return(
        <div className="home-img">
            <img src="/patient.jpg" style={{width: '100%', height:'858px'}} />
        </div>
    )
}