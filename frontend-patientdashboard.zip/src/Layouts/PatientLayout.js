import Navbar from "../Patient/Navbar"


const PatientLayouts = () => {
    return (
        <>
            <Homepage />           
        </>
    )
}

export default PatientLayouts