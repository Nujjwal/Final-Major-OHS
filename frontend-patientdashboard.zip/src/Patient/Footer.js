import React from 'react';
import {
  MDBFooter,
  MDBContainer,
  MDBCol,
  MDBRow,
  MDBIcon,
  MDBBtn
} from 'mdb-react-ui-kit';
import { SocialIcon } from 'react-social-icons';

export default function App() {
  return (
    <MDBFooter className='text-center text-white footer fixed-bottom' style={{ backgroundColor: '#81c784' }}>
      <MDBContainer className='pt-3'>
        <section className='mb-4' >
          <MDBBtn
            rippleColor="dark"
            color='link'
            floating
            size="lg"
            className='text-dark m-1'
            href='#!'
            role='button'
          >
            <SocialIcon url="https://facebook.com" className='pt-1' style={{height:"40px", width:"40px"}}/>
          </MDBBtn>

          <MDBBtn
            rippleColor="dark"
            color='link'
            floating
            size="lg"
            className='text-dark m-1'
            href='#!'
            role='button'
          >
            <SocialIcon url="https://twitter.com" className='pt-1' style={{height:"40px", width:"40px"}}/>
          </MDBBtn>

          <MDBBtn
            rippleColor="dark"
            color='link'
            floating
            size="lg"
            className='text-dark m-1'
            href='#!'
            role='button'
          >
            <SocialIcon url="https://google.com" className='pt-1' style={{height:"40px", width:"40px"}}/>
          </MDBBtn>

          <MDBBtn
            rippleColor="dark"
            color='link'
            floating
            size="lg"
            className='text-dark m-1'
            href='#!'
            role='button'
          >
            <SocialIcon url="https://linkedin.com" className='pt-1' style={{height:"40px", width:"40px"}} />
          </MDBBtn>

          <MDBBtn
            rippleColor="dark"
            color='link'
            floating
            size="lg"
            className='text-dark m-1'
            href='#!'
            role='button'
          >
            <SocialIcon url="https://instagram.com" className='pt-1'  style={{height:"40px", width:"40px"}}/>
          </MDBBtn>

          <MDBBtn
            rippleColor="dark"
            color='link'
            floating
            size="lg"
            className='text-dark m-1'
            href='#!'
            role='button'
          >
          </MDBBtn>
        </section>
      </MDBContainer>

      <div className='text-center text-dark p-3 bg-success'>
        Online Healthcare System © 2020 Copyright
      </div>
    </MDBFooter>
  );
}