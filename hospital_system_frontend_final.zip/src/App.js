import { Route, Routes } from "react-router-dom";
import "./App.css";
import AddDoctor from "./components/adminDashboard/AddDoctor";
import AddSpecialization from "./components/adminDashboard/AddSpecialization";
import EditDoctor from "./components/adminDashboard/EditDoctor";
import Navbar from "./components/adminDashboard/Navbar";
import ViewDoctor from "./components/adminDashboard/ViewDoctor";
import ViewSpecialization from "./components/adminDashboard/ViewSpecialization";

function App() {
  return (
    <div className="App">
      
      <Navbar></Navbar>
      <Routes>
          <Route path="/" element={<ViewDoctor />}></Route>
          <Route path="/ViewSpecialization" element={<ViewSpecialization />}></Route>

          <Route path="/AddDoctor" element={<AddDoctor />}></Route>
          <Route path="/AddSpecialization" element={<AddSpecialization />}></Route>

          <Route path="/editDoctor/:id" element={<EditDoctor />}></Route>

      </Routes>
      
      
    </div>
  );
}

export default App;
