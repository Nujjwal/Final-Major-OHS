import React, { useState } from "react";
import { useNavigate } from "react-router-dom";
import { useEffect } from "react";
import doctorService from "../../service/doctor.service";


const AddDoctor = () => {
    const [doctor, setDoctor] = useState({
        doctor_Name: "",
        doctor_Email: "",
        doctor_Password: "",
        doctor_Specialization: "",
        doctor_Mobile: "",
        doctor_Address: ""
    });

    const [spec, setdropDownSpec] = useState([]);
    const [msg, setMsg] = useState("");
    const navigate = useNavigate();

    useEffect(() => {
        specDropDown();
    }, []);

    const specDropDown = () => {
        doctorService
        .getAllSpecializations()
            .then(response => setdropDownSpec(response.data))
            .catch(error => console.log(error));
    }

    const handleChange = (e) => {
        const value = e.target.value;
        setDoctor({ ...doctor, [e.target.name]: value });
    };

    const submitDoctor = (e) => {
        e.preventDefault();

        doctorService.saveDoctor(doctor).then((res) => {
            setMsg("Doctor saved successfully");
            setDoctor({
                doctor_Name: "",
                doctor_Email: "",
                doctor_Password: "",
                doctor_Specialization: "",
                doctor_Mobile: "",
                doctor_Address: ""
            });
        }).catch((error) => {
            console.log(error);
        });
    };


    return (
        <div className="container">
            <div className="row">
                <div className="col-md-6 offset-md-3">
                    <div className="card">
                        <div className="card-header text-center fs-3">Add Doctor
                            {
                                msg && <p className="text-success">{msg}</p>
                            }
                        </div>
                        <div className="card-body">
                            <form onSubmit={(e) => submitDoctor(e)}>
                                <div className="mb-3">
                                    <label>Enter Full Name</label>
                                    <input className="form-control" type="text"
                                        name="doctor_Name" value={doctor.doctor_Name} onChange={(e) => handleChange(e)} required />
                                </div>
                                <div className="mb-3">
                                    <label>Enter Email</label>
                                    <input className="form-control" type="email"
                                        name="doctor_Email" value={doctor.doctor_Email} onChange={(e) => handleChange(e)} required />
                                </div>
                                <div className="mb-3">
                                    <label>Enter Password</label>
                                    <input className="form-control" type="password"
                                        name="doctor_Password" value={doctor.doctor_Password} onChange={(e) => handleChange(e)} required />
                                </div>
                                <div className="mb-3">
                                    <label>Select Specialization</label>
                                    <select value={doctor.doctor_Specialization} className="form-select" onChange={(e) => handleChange(e)} name="doctor_Specialization" required>
                                        <option value="0">--Select Specialization--</option>
                                        {
                                            spec.map((user) => (
                                                <option key={user.specialization_Id} >{user.doctor_Specialization}</option>
                                            ))
                                        }
                                    </select>
                                </div>
                                <div className="mb-3">
                                    <label>Enter Mobile</label>
                                    <input className="form-control" type="number"
                                        name="doctor_Mobile" value={doctor.doctor_Mobile} onChange={(e) => handleChange(e)} required />
                                </div>
                                <div className="mb-3">
                                    <label>Enter Address</label>
                                    <input className="form-control" type="text"
                                        name="doctor_Address" value={doctor.doctor_Address} onChange={(e) => handleChange(e)} required />
                                </div>
                                <div className="text-center">
                                    <button className="btn btn-success m-2">Submit</button>
                                    <button onClick={() => navigate("/", { replace: true })} className="btn btn-primary">Doctor's List</button>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    );
}

export default AddDoctor;