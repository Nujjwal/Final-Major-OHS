import React, { useState } from "react";
import { useNavigate } from "react-router-dom";
import doctorService from "../../service/doctor.service";

const AddSpecialization = () => {
    const [doctorSpec, setDoctorSpec] = useState({
        doctor_Specialization: ""
    });

    const [msg, setMsg] = useState("");
    const navigate = useNavigate();


    const handleChange = (e) => {
        const value = e.target.value;
        setDoctorSpec({ ...doctorSpec, [e.target.name]: value });
    };

    const submitDoctorSpec = (e) => {
        e.preventDefault();

        doctorService
        .addSpecialization(doctorSpec).then((res) => {
            setMsg("Doctor Specialization saved successfully");
            setDoctorSpec({
                doctorSpecialization: ""
            });
        }).catch((error) => {
            console.log(error);
        });
    };


    return (
        <div className="container">
            <div className="row">
                <div className="col-md-6 offset-md-3">
                    <div className="card">
                        <div className="card-header text-center fs-3">Add Doctor Specialization
                            {
                                msg && <p className="text-success">{msg}</p>
                            }
                        </div>
                        <div className="card-body">
                            <form onSubmit={(e) => submitDoctorSpec(e)}>
                                <div className="mb-3">
                                    <label>Enter Specialization</label>
                                    <input className="form-control" type="text"
                                        name="doctor_Specialization" value={doctorSpec.doctor_Specialization} onChange={(e) => handleChange(e)} required />
                                </div>
                                <div className="text-center">
                                    <button className="btn btn-success m-2">Submit</button>
                                    <button onClick={() => navigate("/ViewSpecialization", { replace: true })} className="btn btn-primary">Specialization List</button>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    );
}

export default AddSpecialization;