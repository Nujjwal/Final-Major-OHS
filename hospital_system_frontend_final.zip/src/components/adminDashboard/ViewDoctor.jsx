import React, { useEffect, useState } from "react";
import { Link } from "react-router-dom";
import { useNavigate } from "react-router-dom";
import doctorService from "../../service/doctor.service";


const ViewDoctor = () => {

    const [doctorList, setDoctorList] = useState([]);
    const [msg, setMsg] = useState("");
    const navigate = useNavigate();


    useEffect(() => {
        init();
    }, []);

    const init = () => {
        doctorService
        .getAllDoctor().then((res) => {
            // console.log(res.data);
            setDoctorList(res.data);
        })
        .catch((error) => {
            console.log(error);
        });
    };

    const deleteDoctor = (doctor_Id) => {
        // console.log(d_Id);
        doctorService.deleteDoctor(doctor_Id).then((res) => {
            setMsg("Deleted Successfully");
            init();
        }).catch((error) => {
            console.log(error);
        });
    }

    return (
        <div className="container">
            <h1 className="text-center mt-3">HealthCare System</h1>
            {msg && <p className="text-center text-success">{msg}</p>}
            <table className="table mt-5">
                <thead className="bg-light">
                    <tr>
                        <th scope="col">Id</th>
                        <th scope="col">Doctor_Name</th>
                        <th scope="col">Doctor_Email</th>
                        <th scope="col">Doctor_Password</th>
                        <th scope="col">Doctor_Specialization</th>
                        <th scope="col">Doctor_Mobile</th>
                        <th scope="col">Doctor_Address</th>
                        <th scope="col" >Action</th>
                    </tr>
                </thead>
                <tbody>
                    {doctorList.map((e, num) => (
                        <tr>
                            <th scope="row" key={e.doctor_Id}>{num + 1}</th>
                            <td>{e.doctor_Name}</td>
                            <td>{e.doctor_Email}</td>
                            <td>{e.doctor_Password}</td>
                            <td>{e.doctor_Specialization}</td>
                            <td>{e.doctor_Mobile}</td>
                            <td>{e.doctor_Address}</td>
                            <td>
                                <Link to={"editDoctor/" + e.doctor_Id} className="btn btn-sm btn-primary m-2">
                                    Edit
                                </Link>
                                <a onClick={() => deleteDoctor(e.doctor_Id)} className="btn btn-sm btn-danger" href="#">Delete</a>
                            </td>
                        </tr>
                    ))}
                </tbody>
            </table>
            <div className="text-center">
            <button onClick={() => navigate("/AddDoctor", { replace: true })} className="btn btn-primary">Add Doctor</button>
        </div>
        </div>
    );
}

export default ViewDoctor;


