import axios from "axios";


const BASE_API_URL = "http://localhost:8080/doctor";


class DoctorService{

    saveDoctor(doctor){
        return axios.post(BASE_API_URL + "/save/", doctor);
    }

    getAllDoctor(){
        return axios.get(BASE_API_URL + "/" );
    }

    getDoctorById(doctor_Id){
        return axios.get(BASE_API_URL + "/" + doctor_Id);
    }

    deleteDoctor(doctor_Id){
        return axios.delete(BASE_API_URL + "/delete/" + doctor_Id);
    }

    updateDoctor(doctor_Id,doctor){
        return axios.post(BASE_API_URL + "/update/" + doctor_Id, doctor);
    }

    addSpecialization(doctorSpecialization){
        return axios.post(BASE_API_URL + "/addSpec/", doctorSpecialization);
    }

    getAllSpecializations(){
        return axios.get(BASE_API_URL + "/viewSpec" );
    }

    getSpecializationById(specialization_Id){
        return axios.get(BASE_API_URL + "/viewSpecById/" + specialization_Id);
    }

    deleteSpecialization(specialization_Id){
        return axios.delete(BASE_API_URL + "/deleteSpec/" +  specialization_Id);
    }

}

export default new DoctorService();