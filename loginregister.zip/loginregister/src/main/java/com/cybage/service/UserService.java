package com.cybage.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cybage.model.User;
import com.cybage.repository.UserRepository;

@Service
public class UserService {
	@Autowired
	UserRepository userepository;

	public User addUser(User user) {
		return userepository.save(user);
	}

	public List<User> getAllUser() {
		return userepository.findAll();
	}

	public User getUserById(int id) {
		return userepository.findById(id).get();
	}

	public void delete(int id) {
		User user = userepository.findById(id).get();
		if (user != null) {
			userepository.delete(user);
		}
	}

	public User getUserByEmail(String email) {
		return userepository.findByEmail(email);
	}

	public boolean isPasswordCorrect(User user) {
			return getUserByEmail(user.getEmail()).getPassword().equals(user.getPassword());
	}

	public User loginMethod(String email, String pass) {
		return userepository.login(email, pass);
	}

}
