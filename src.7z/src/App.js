import './App.css';
import Appfeedback from './component/Appfeedback';
import { useEffect } from 'react';
import Navbar from './component/Navbar';
// import { Routes,Route } from 'react-router-dom';


function App() {
  useEffect(()=>{
    fetch('localhost:8083/feedbacks/')
      },[]);
  return (
    <div className="App">
      
      <Appfeedback></Appfeedback>
    </div>
  );
}

export default App;
