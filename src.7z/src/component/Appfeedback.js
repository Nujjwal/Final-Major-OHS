import React, { useState } from "react";
import './feedback.css';
import feedbackService from "../services/feedbackServices";



function Appfeedback() {
  const [model, setModel] = useState(
    {
      patient_name:"",
      patient_email:"",
      rating_count:"",
      ratin_msg:""
    });

    const[data,setdata]=useState("");

    const handleChange = (e) => {
      const value = e.target.value;
      setModel({...model,[e.target.name]:value});
    };

    const submitFeedback = (e) => {
      e.preventDefault();

      feedbackService.addFeedback(model).then((res)=>{
        setdata("Feedback saved successfully");
        setModel({
          patient_name:"",
          patient_email:"",
          rating_count:"",
          ratin_msg:""
        });  
      }).catch((error)=>{
          console.log(error);
      });

    };
  return (
    
    <div>
      <h1>Feedback Form</h1>
      
      <div >
        
          <form className="formbody">
            <div className="user-box">
              <input placeholder="Name" name="patient_name" value={model.patient_name} onChange={(e)=>handleChange(e)} required/>
            </div>
            <br></br>
            <div className="user-box">
              <input placeholder="Email" type="email" name="patient_email" value={model.patient_email} onChange={(e)=>handleChange(e)} required/>
            </div>
            <br></br>
            <div className="user-box">
              <input placeholder="Rating" name="rating_count" value={model.rating_count} onChange={(e)=>handleChange(e)} required/>
            </div>
            <br></br>
            <div className="user-box" >
              <input placeholder="Rating Message" type="text-box" name="ratin_msg" value={model.ratin_msg} onChange={(e)=>handleChange(e)} required/>
            </div>
            <br></br>
            <button type="submit" onSubmit={(e) => submitFeedback(e)} name="submit" ><a>Submit Feedback</a></button>
          </form>
      </div>
    </div>
  );
}

export default Appfeedback;
