import axios from "axios";

const BASE_API_URL = "https://localhost:8083/feedbacks";

class feedbackService{

    
    addFeedback(feedback){
        return axios.post(BASE_API_URL + "/add" , feedback);
    }

    getFeedback(){
        return axios.get(BASE_API_URL + "/" );
    }

    getFeedbackByID(Id){
        return axios.get(BASE_API_URL + "/{id}" + Id);
    }

}
export default new feedbackService; 