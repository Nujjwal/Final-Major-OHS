export const base_url = 'localhost:8080/appointment';
export const getAllAppointment = base_url + '/';