import { NavLink, Route, Routes } from 'react-router-dom';
import './App.css';
import AppointmentDisplay from './components/Appointment';
import Appointment from './components/Appointment';
import Navbar from './components/Navbar';
import DoctorHome from './DoctorHome';



function App() {
  
  return (
    <div className="App">
      <Navbar/>
      
      <DoctorHome>
      <Routes>
      <Route path="/" element={<DoctorHome/>}/>
      <NavLink exact path="/Appointment" component={<AppointmentDisplay/>}/>

      </Routes>
      </DoctorHome>

  
    </div>
  );
  
}

export default App;
