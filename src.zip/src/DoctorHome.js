import React from "react";
import { Link, Route, Routes } from "react-router-dom";
import Appointment from "./components/Appointment";
import './components/DoctorHome.css'
import { useEffect } from "react";
function DoctorHome() {
  useEffect(()=>{
    fetch('localhost:8080/appointment/')
      },[]);
      
  return (
  
    <>
    <div>
     <h1>Welcome Doctor</h1></div>
    <div>
      
      {/* <div className="Appheader">Welcome Doctor</div> */}
    {/* //   <div>
    //     <body className="Appbody">
    //       <div class="container">
    //         <div class="row">
    //           <div class="col-sm" className="Appbutton">
    //             <Link to="/appointment">
    //               <button type="button" class="btn btn-dark" >
    //                 View Appointment
    //               </button>
    //             </Link>

    //           </div>

    //           <div class="col-sm" className="Appbutton">
    //             <button type="button" class="btn btn-dark">
    //               View Feedback
    //             </button>
    //           </div>

    //           <div class="col-sm" className="Appbutton">
    //             <button type="button" class="btn btn-dark">
    //               Change Password
    //             </button>
    //           </div>
    //         </div>
    //       </div>
    //     </body>
    //   </div> */}
      <Routes>
        <Route path="/appointment" exact element={<Appointment/>}></Route>
      </Routes>
      </div>
   
    </>
  );
}

export default DoctorHome;
