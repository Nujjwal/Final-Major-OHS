import React, { useEffect, useState } from "react";
import axios from "axios";
import { Link } from "react-router-dom";
import "./Appointment.css";

const  BASE_URL = 'http://localhost:8083/appointment/';

export default function AppointmentDisplay(){
    const [appointments, setappointments] = useState([])

    useEffect(() => {
        console.log("UseEffect");
        axios.get(BASE_URL)
            .then((response) => {
                setappointments(response.data);
            })
    }, [])
    return(
        <div>
        <table className = "table table-striped">
                                    <thead className="th">
                                        <tr>
                                            <th scope="col">Appointment Id</th>
                                            <th scope="col">Appointment Description</th>
                                            <th scope="col">Doctor Name</th>
                                            <th scope="col">Doctor Email</th>
                                            <th scope="col" >Patient Name</th>
                                            <th scope="col">Patient Age</th>
                                            <th scope="col">Patient Address</th>      
                                        </tr>
                                    </thead>
                                <tbody>
                    {appointments.map((appointment) => (
                        <tr>
                           
                            {/* <th scope="row" key={Appointment.a_Id}></th> */}
                            <td>{appointment.a_Id}</td>
                            <td>{appointment.a_Desc}</td>
                            <td>{appointment.doc.d_Name}</td>
                            <td>{appointment.doc.d_Email}</td>
                            <td>{appointment.pat.p_Name}</td>
                            <td>{appointment.pat.p_Age}</td>
                            <td>{appointment.pat.p_Address}</td>

                    
                           
                        </tr>
                    ))}
                </tbody>                
            </table>
            <Link to={"App/"} className="btn btn-sm btn-primary m-2 center">
            Back
        </Link>
        </div>
    )
}