import axios from 'axios'

const BASE_API_URL = 'http://localhost:8083/appointment';
6
class AppointmentService{
    saveAppointment(Appointment){
        return axios.post(BASE_API_URL+"/save/"+Appointment);
    }

    getAllAppointment(){
        return axios.get(BASE_API_URL+"/");
    }
    getAllAppointmentById(a_Id){
        return axios.get(BASE_API_URL+"/"+a_Id);
    }
    deleteAppointment(a_Id){
        return axios.get(BASE_API_URL+"/delete/"+a_Id);
    }


}
export default new AppointmentService();
