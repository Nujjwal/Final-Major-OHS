import React, { useEffect, useState } from "react";
import appointmentService from "../service/appointment.service";


const ViewAppointment = () => {

    const [appointmentList, setAppointmentList] = useState([]);
    const [msg, setMsg] = useState("");


    useEffect(() => {
        init();
    }, []);

    const init = () => {
        appointmentService
        .getAllAppointment().then((res) => {
            setAppointmentList(res.data);
        })
        .catch((error) => {
            console.log(error);
        });
    };

    const deleteAppointment = (appointment_Id) => {
        appointmentService.deleteAppointment(appointment_Id).then((res) => {
            setMsg("Deleted Successfully");
            init();
        }).catch((error) => {
            console.log(error);
        });
    }

    return (
        <div className="container">
            <h1 className="text-center mt-3">HealthCare System</h1>
            {msg && <p className="text-center text-success">{msg}</p>}
            <table className="table mt-5">
                <thead className="bg-light">
                    <tr>
                        <th scope="col">Id</th>
                        <th scope="col">Appointment_Status</th>
                        <th scope="col">Appointment_DateTime</th>
                        <th scope="col">Appointment_BookedOn</th>
                        <th scope="col">Doctor_Name</th>
                        <th scope="col">Patient_Name</th>
                        <th scope="col" >Action</th>
                    </tr>
                </thead>
                <tbody>
                    {appointmentList.map((e, num) => (
                        <tr>
                            <th scope="row" key={e.appointment_Id}>{num + 1}</th>
                            <td>{e.appointment_Status}</td>
                            <td>{e.appointment_DateTime}</td>
                            <td>{e.BookedOn}</td>
                            <td>{e.doctor_Name}</td>
                            <td>{e.patient_Name}</td>
                            <td>
                                <a onClick={() => deleteAppointment(e.appointment_Id)} className="btn btn-sm btn-danger" href="#">Delete</a>
                            </td>
                        </tr>
                    ))}
                </tbody>
            </table>
            <div className="text-center">
        </div>
        </div>
    );
}

export default ViewAppointment;


