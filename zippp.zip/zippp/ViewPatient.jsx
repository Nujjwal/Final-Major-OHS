import React, { useEffect, useState } from "react";
import patientService from "../service/patient.service";


const ViewPatient = () => {

    const [patientList, setPatientList] = useState([]);
    const [msg, setMsg] = useState("");


    useEffect(() => {
        init();
    }, []);

    const init = () => {
        patientService
        .getAllPatient().then((res) => {
            setPatientList(res.data);
        })
        .catch((error) => {
            console.log(error);
        });
    };

    const deletePatient = (patient_Id) => {
        patientService.deletePatient(patient_Id).then((res) => {
            setMsg("Deleted Successfully");
            init();
        }).catch((error) => {
            console.log(error);
        });
    }

    return (
        <div className="container">
            <h1 className="text-center mt-3">HealthCare System</h1>
            {msg && <p className="text-center text-success">{msg}</p>}
            <table className="table mt-5">
                <thead className="bg-light">
                    <tr>
                        <th scope="col">Id</th>
                        <th scope="col">Patient_Name</th>
                        <th scope="col">Patient_Email</th>
                        <th scope="col">Patient_Password</th>
                        <th scope="col">Patient_Specialization</th>
                        <th scope="col">Patient_Mobile</th>
                        <th scope="col">Patient_Address</th>
                        <th scope="col" >Action</th>
                    </tr>
                </thead>
                <tbody>
                    {patientList.map((e, num) => (
                        <tr>
                            <th scope="row" key={e.patient_Id}>{num + 1}</th>
                            <td>{e.patient_Name}</td>
                            <td>{e.patient_Email}</td>
                            <td>{e.patient_Password}</td>
                            <td>{e.patient_Age}</td>
                            <td>{e.patient_Sex}</td>
                            <td>{e.patient_Address}</td>
                            <td>
                                <a onClick={() => deletePatient(e.patient_Id)} className="btn btn-sm btn-danger" href="#">Delete</a>
                            </td>
                        </tr>
                    ))}
                </tbody>
            </table>
            <div className="text-center">
        </div>
        </div>
    );
}

export default ViewPatient;


