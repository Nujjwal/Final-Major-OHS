import axios from "axios";


const BASE_API_URL = "http://localhost:8080/appointment";


class AppointmentService{

    savePatient(appointment){
        return axios.post(BASE_API_URL + "/save/", appointment);
    }

    getAllAppointment(){
        return axios.get(BASE_API_URL + "/" );
    }

    getAppointmentById(appointment_Id){
        return axios.get(BASE_API_URL + "/" + appointment_Id);
    }

    deleteAppointment(appointment_Id){
        return axios.delete(BASE_API_URL + "/delete/" + appointment_Id);
    }

}

export default new AppointmentService();