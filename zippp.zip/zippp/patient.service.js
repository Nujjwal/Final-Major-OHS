import axios from "axios";


const BASE_API_URL = "http://localhost:8080/patient";


class PatientService{

    savePatient(patient){
        return axios.post(BASE_API_URL + "/save/", patient);
    }

    getAllPatient(){
        return axios.get(BASE_API_URL + "/" );
    }

    getPatientById(patient_Id){
        return axios.get(BASE_API_URL + "/" + patient_Id);
    }

    deletePatient(patient_Id){
        return axios.delete(BASE_API_URL + "/delete/" + patient_Id);
    }

}

export default new PatientService();